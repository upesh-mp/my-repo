
public class Car {

    private String make;
    private String model;
    private String[] options;
    private String[] parts;
    private double price;

    public void setMake(String m) {
        make = m;
    }

    public String getMake() {
        return make;
    }

    public void setModel(String m) {
        model = m;
    }

    public String getModel() {
        return model;
    }

    public void setOptions(String[] o) {
        options = o;
    }

    public String[] getOptions() {
        return options;
    }

    public void setParts(String[] p) {
        parts = p;
    }

    public String[] getParts() {
        return parts;
    }

    public void setPrice(double p) {
        price = p;
    }

    public double getPrice() {
        return price;
    }

    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(String.format("Make: %s\n", make));
        builder.append(String.format("Model: %s\n", model));
        builder.append("Options:\n");

        for (int i = 0 ; i < 8 ; i++) {
            builder.append(String.format("%s: %s\n", AnyCarMain.sections[i],options[i]));
        }

        builder.append("Parts:\n");
        builder.append(String.format("Model: %s $%s\n", model, parts[0]));
        
        for (int i = 1 ; i < 9 ; i++) {
            builder.append(String.format("%s %s: $%s\n", AnyCarMain.sections[i-1], options[i-1], parts[i]));
        }

        builder.append(String.format("Price: $%.2f\n", price));
        return builder.toString();
    }

}