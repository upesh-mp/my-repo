
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

/*
 * Name: 
 * Class: 
 * Date:
 * Description: AnyCarMain is the main file of your application. Main will read 
 * in the configuration file and initiate the application.
 */

public class AnyCarMain {

    private static String[] anyCarConfig = new String[52]; // Global String Array Manufactoring Configuration
    private static HashMap<String, Integer> map = new HashMap<>();
    static String[] sections = new String[] { "Exterior Color", "Interior Color",
            "Powertrain", "Seat","Radio","Tire","Rim","Miscellaneous"
    };
    
    /*
     * Input: String Array args â€“ Command line arguments
     * Return: Void
     * Description: Main Method for initiating AnyCar application. When called 
     * will read line by line AnyCar.config file and append to global variable 
     * anyCarConfig. Finally, Main will call request to initiate the interaction
     * with the user.
     */
    public static void main(String[] args) {
        List<String> sectionList = Arrays.asList(sections);

        AnyCarMain main = new AnyCarMain();
        InputStream stream = main.getClass().getResourceAsStream("AnyCar.config");
		Scanner sc = new Scanner(stream);
        for(int i = 0 ; i < 52 ; i++) {
            if(sc.hasNextLine()) {
                String line = sc.nextLine();
                
                int offset = sectionList.indexOf(line);
                if(offset > -1) {
                    map.put(line, i);
                }
                anyCarConfig[i] = line;
            }
        }
        request();
        //testing a car before user input
        //buildVehicle("000111111110");
    }

    /*
     * Input: None
     * Return: Void
     * Description: Requests user to input PID(String) and calls buildVehicle
     * to start building each vehicle. Request will continue to prompt the user 
     * until the user inputs -1, then request will return. 
     */
    public static void request() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter a 12 digit PID");
        while(true) {
            String line = sc.nextLine();
            if(line.equals("-1")) {
                break;
            }
            if(line.length() != 12) {
                System.err.println("Thats not a valid PID");
                continue;
            }
            buildVehicle(line);
        }
    }

    /*
     * Input: String pid - 12-digit product ID number
     * Return: Void
     * Description: Create Car object and call getters and setters for make, 
     * model, options, parts, and price using 
     * AnyCarMain methods [getModel, getOptions, getParts, getPrice] and set the
     * make to â€˜AnyCarâ€™, finally print the Car object using itâ€™s toString method,
     * and return 
     */
    public static void buildVehicle(String id) {
        Car car = new Car();
        car.setModel(getModel(id));
        car.setMake("AnyCar");
        car.setOptions(getOptions(id));
        car.setParts(getParts(id, car.getOptions()));
        car.setPrice(getPrice(car.getParts()));
        System.out.println(car);
        
    }

    /*
     * Input: String pid - 12-digit product ID number
     * Return: String Model Name
     * Description: Reads first 4 numbers, find the four numbers within 
     * anyCarConfig, and return only the model Name. 
     */
    public static String getModel(String id) {
        for(String line : anyCarConfig) {
            String[] parts = line.split(" ");
            if(parts[0].equals(id.substring(0,4))) {
                return parts[1];
            }
        }
        return null;
    }

    /*
     * Input: String pid - 12-digit product ID number
     * Return: returns a String Array of options
     * Description: Reads the last 8 numbers of pid and identifies the options within anyCarConfig as follows:
     * Index 1.Exterior Color
     * Index 2.Interior Color
     * Index 3.Powertrain
     * Index 4.Seat Type
     * Index 5.Radio Type
     * Index 6.Tire Type
     * Index 7.Rim Size
     * Index 8.Miscellaneous
     * If the number is zero then the option is None. Each option is appended 
     * to an array with the option name and type as string example: 
     *   â€œExterior Color: Whiteâ€ once all options are defined then return the 
         array of options.
     */
    public static String[] getOptions(String id) {
       
        String[] options = new String[8];
        int i = 4;
        
        for(String s: sections) {
            char c = id.charAt(i);
            if(c == '0') {
                options[i - 4] = "None";
            }
            else {
                for(int offset = map.get(s) ; offset < 52 ; offset++) {
                    String[] parts = anyCarConfig[offset].split(" ");
                    if (parts[0].charAt(0) == c) {
                        options[i - 4] = parts[1];
                        //testing options
                        //System.out.printf("%s %s \n",s, parts[1]);
                        break;
                    }
                }
            }
            i++;
        } 

        return options;
    }
    
    /*
     * Input: String id â€“ 4-digit model number, String Array options â€“ 
     *    List of options from getOptions
     * Return: String Array of Parts
     * Description: id is the model number of the vehicle and the price of each 
     *  model is within anyCarConfig, use the options Array to identify the
     * prices of each part and return an Array of parts with each index as a 
     * String example: â€œPart1: $10.00â€
     */
    public static String[] getParts(String id, String[] options) {

        String[] parts = new String[9];
        String[] model = anyCarConfig[0].split(" ");
        if(model[0].equals(id)) {
            parts[0] = model[2];
        }
        else {
            model = anyCarConfig[1].split(" ");
            parts[0] = model[2];
        }
        
        int option = 0;
        for(String section: sections) {
            for(int i = map.get(section)+1 ; i < 52 ; i++) {
                if(options[option].equals("None")) {
                    break;
                }
              //  System.out.printf("%s | %s | %s\n", section, options[option], anyCarConfig[i]);
                
                String[] split = anyCarConfig[i].split(" ");
                if(split.length == 3 && split[1].equals(options[option])) {
                    parts[option + 1] = split[2];
                    break;
                }
            }
            option++;
        }
        
        for(String part: parts) {
        	//THIS IS TO PRINT VALUES OF PARTS TO ADD
            //System.err.println(part);
        }
        return parts;
    }

    /*
     * Input: String Array parts â€“ List of parts from getParts
     * Return: double cost
     * Description: Iterate through parts and combine the cost of all parts
     * and return the total cost
     */
    public static double getPrice(String[] parts) {

        double cost = 0.0;
        
        for(String part: parts) {
            if(part != null) {
                //System.err.println(part);
                String[] split = part.split(": ");
                cost += Double.parseDouble(split[split.length -1]);
            }
        }
        
        return cost;
    }

}