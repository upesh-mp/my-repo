package assignment1;

import java.util.ArrayList;

import javafx.application.Platform;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebHistory.Entry;
import javafx.scene.web.WebHistory;
import javafx.scene.web.WebView;

public class Menus {

	/**** Generic Menu/Menu Item Properties ****/
	private static MenuItem mnuItm;
	private static Menu mnu;

	/********* Address Bar Properties **********/
	private static VBox topPanel = new VBox();
	private static VBox rightPanel = new VBox();
	private static VBox bottomPanel = new VBox();
	private static HBox hbxAddressBar;
	private static TextField txtfldAddress;
	private static Button btnGo;
	private static boolean toggleAddress = true;
	private static boolean toggleHistoryBar = true;
	
	private static TableView<String> table = new TableView<String>();
	/********* Bookmarks Properties **********/
	private static ArrayList<String> bookmarkURLs = new ArrayList<>();

	
	/**************** MenuBar ****************/
	public static MenuBar getMenuBar(WebView wv) {
		MenuBar menuBar = new MenuBar();
		menuBar.getMenus().addAll(getMnuFile(wv), getMnuSettings(wv), getMnuBookmarks(), getMnuHelp());
		return menuBar;
	}

	
	/***************** Menu ******************/
	private static Menu getMnuFile(WebView wv) {
		mnu = new Menu("File");
		mnu.getItems().addAll(getMnuItmRefresh(wv), getMnuItmExit());
		return mnu;
	}

	private static Menu getMnuSettings(WebView wv) {
		mnu = new Menu("Settings");
		mnu.getItems().addAll(getMnuItmAddressBar(), getMnuItmSaveStartupPage(), getMnuHistBar(wv));
		return mnu;
	}

	private static Menu getMnuBookmarks() {
		mnu = new Menu("Bookmarks");
		mnu.getItems().addAll(getMnuItmBookmarks(mnu));
		loadBookmarksToMenu(mnu);
		return mnu;
	}

	private static Menu getMnuHelp() {
		mnu = new Menu("Help");
		mnu.getItems().addAll(getMnuItmJavaHelp(), getMnuItmAbout());
		return mnu;
	}

	
	public static MenuItem createMenuItem(String menuItemName, KeyCode acceleratorKey, EventHandler<ActionEvent> handler) {
		mnuItm = new MenuItem(menuItemName);
		mnuItm.setOnAction(handler);;
		mnuItm.setAccelerator(new KeyCodeCombination(acceleratorKey, KeyCombination.ALT_DOWN));
		return mnuItm;
	}
	
	/*************** MenuItems ***************/
	
	
	
	private static MenuItem getMnuHistBar(WebView wv) {
		
		return createMenuItem("View History", KeyCode.H, (ActionEvent e) -> {
			if (toggleHistoryBar) {
				
				table.getColumns().clear();
				TableColumn<String, String> firstNameCol = new TableColumn<String, String>("History");
				table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
				table.getColumns().add(firstNameCol);
				ObservableList<String> histories =FXCollections.observableArrayList(); 
				for( Entry entry: wv.getEngine().getHistory().getEntries()) {
					histories.add(entry.toString());
				}
				table.setItems(histories);;
				firstNameCol.setCellValueFactory(cellData -> 
			    new ReadOnlyStringWrapper(cellData.getValue()));
				rightPanel.getChildren().add(table);
				Button backwardButton = new Button("Backward");
				Button forwardButton = new Button("Forward");
				
				if(wv.getEngine().getHistory().getCurrentIndex() >= 0) {
					backwardButton.setDisable(false);
				}
				if(wv.getEngine().getHistory().getCurrentIndex() == wv.getEngine().getHistory().getEntries().size()-2 ) {
					forwardButton.setDisable(true);
				}
				if(wv.getEngine().getHistory().getCurrentIndex() == 1) {
					backwardButton.setDisable(true);
				}
				if(wv.getEngine().getHistory().getCurrentIndex() < wv.getEngine().getHistory().getEntries().size() ) {
					forwardButton.setDisable(false);
				}
				forwardButton.setOnAction((ActionEvent e1) -> {
					
					
					if(wv.getEngine().getHistory().getCurrentIndex() < wv.getEngine().getHistory().getEntries().size()-1 ) {
						Platform.runLater(new Runnable() { public void run() { wv.getEngine().getHistory().go(+1); } });
					}
					if(wv.getEngine().getHistory().getCurrentIndex() >= 0) {
						backwardButton.setDisable(false);
					}
					if(wv.getEngine().getHistory().getCurrentIndex() == wv.getEngine().getHistory().getEntries().size()-2 ) {
						forwardButton.setDisable(true);
					}
					
				});
				backwardButton.setOnAction((ActionEvent e2) ->  {
					
					if(wv.getEngine().getHistory().getCurrentIndex() > 0 ) {
						Platform.runLater(new Runnable() { public void run() { wv.getEngine().getHistory().go(-1); } });
					}
					if(wv.getEngine().getHistory().getCurrentIndex() == 1) {
						backwardButton.setDisable(true);
					}
					if(wv.getEngine().getHistory().getCurrentIndex() < wv.getEngine().getHistory().getEntries().size() ) {
						forwardButton.setDisable(false);
					}
				});
				bottomPanel.getChildren().clear();
				bottomPanel.getChildren().addAll(backwardButton, forwardButton);
			}	
			else {
				rightPanel.getChildren().remove(table);
			}
			toggleHistoryBar = !toggleHistoryBar;
		});
	}
	
	private static MenuItem getMnuItmRefresh(WebView wv) {
		
		return createMenuItem("Refresh", KeyCode.R, (ActionEvent e) -> wv.getEngine().reload());
	}

	private static MenuItem getMnuItmExit() {
		return createMenuItem("Exit", KeyCode.E, (ActionEvent e) -> Platform.exit());
	}

	private static MenuItem getMnuItmSaveStartupPage() {
		return createMenuItem("Save Current Page as Startup", KeyCode.S, (ActionEvent e) -> {
			String currentURL = getCurrentURL();
			if (currentURL.length() > 0) {                  // if the currentURL is not ""...
				ArrayList<String> al = new ArrayList<>();
				al.add(currentURL);							// ...load it into the ArrayList and save it to the file
				FileUtils.storeURLsToFile(al, "default.web");
			}			
		});
	}

	private static MenuItem getMnuItmAddressBar() {
		
		return createMenuItem("Show/Hide Address Bar", KeyCode.A, (ActionEvent e) -> {
			if (toggleAddress)
				topPanel.getChildren().add(hbxAddressBar);
			else
				topPanel.getChildren().remove(hbxAddressBar);
			toggleAddress = !toggleAddress;
		});
	}

	private static MenuItem getMnuItmBookmarks(Menu mnuBookmarks) {
		
		return createMenuItem("Add Bookmark", KeyCode.B, (ActionEvent e) -> {
			addBookmarkToMenu(mnuBookmarks, getCurrentURL());
			getBookmarks().add(getCurrentURL());
		});
	}

	private static MenuItem getMnuItmJavaHelp() {
		
		return createMenuItem("Java Help", KeyCode.J, (ActionEvent e) -> goToURL("https://www.google.ca/search?q=java"));
		
	}

	private static MenuItem getMnuItmAbout() {
		
		return createMenuItem("About", KeyCode.P, (ActionEvent e) -> {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("About");
			alert.setHeaderText("Dave's Browser");
			alert.setContentText("Code by Prof. Dave Houtman, �2017");
			alert.showAndWait();
		});
	}
	
	public static VBox loadTopPanel(WebView wv) {
		hbxAddressBar = createAddressBar(wv);  
		MenuBar mb = getMenuBar(wv);
	    topPanel.getChildren().add(mb);
	    return topPanel;
	}
	
	public static VBox getRightPanel() {
		return rightPanel;
	}
	public static VBox getBottomPanel() {
		return bottomPanel;
	}
	

	
	/*************** Address Bar Methods ***************/
	public static HBox createAddressBar(WebView wv) {

		Label lblEnterURL = new Label("Enter URL:");
		lblEnterURL.setPadding(new Insets(4, 4, 4, 4));

		txtfldAddress = new TextField();
		
		txtfldAddress.setOnKeyPressed(e -> {
			 if (e.getCode() ==
					 KeyCode.ENTER){
				 wv.getEngine().load(getCurrentURL());
					 }
		});
		btnGo = new Button("Go");
		btnGo.setOnAction((ActionEvent e) -> wv.getEngine().load(getCurrentURL()));
		
		HBox hbx = new HBox();	
		hbx.getChildren().addAll(lblEnterURL, txtfldAddress, btnGo);
		hbx.setHgrow(txtfldAddress, Priority.ALWAYS);
		return hbx;
	}
	
	public static void setURL(String URL) {txtfldAddress.setText(URL);}
	private static String getCurrentURL() {return txtfldAddress.getText();}
	
	public static void goToURL(String URL) {
		setURL(URL);
		btnGo.fire();
	}

	
	/*************** Bookmarks Methods ***************/
	
	public static ArrayList<String> getBookmarks(){return bookmarkURLs;}
	public static void setBookmarks(ArrayList<String> al) { bookmarkURLs = al;}
	
	private static void loadBookmarksToMenu(Menu mnu) {
		if (FileUtils.fileExists("bookmarks.web")){
			setBookmarks(FileUtils.getURLsFromFile("bookmarks.web"));
			for (String url: bookmarkURLs)
				addBookmarkToMenu(mnu, url);
		}
	}
	
	private static void addBookmarkToMenu(Menu mnu, String URL) { 
		mnuItm = new MenuItem(URL);
		mnuItm.setOnAction((ActionEvent e) -> goToURL(URL));
		if (mnu.getItems().size() == 1)
			mnu.getItems().add(new SeparatorMenuItem());
		mnu.getItems().add(mnuItm); // Add new URL to Menu
	}

}
