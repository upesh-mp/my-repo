/**
 * FileName: Menus.java
 * Author: Manveer, ID
 * Course: 
 * Assignment: 2
 * Date: 11/1/2018
 * Professor: 
 * Purpose: 
 */

package assignment2;

import java.io.StringWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Worker;
import javafx.concurrent.Worker.State;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.CustomMenuItem;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebHistory;
import javafx.scene.web.WebHistory.Entry;
import javafx.scene.web.WebView;

/**
 * @author Manveer
 * @version 1.0
 * @see java.io java.util java.net javax.xml  javafx
 * @since 1.8
 */
public class Menus {

	/**** Generic Menu/Menu Item Properties ****/
	/**
	 * The menu item reference
	 */
	private static MenuItem mnuItm;
	/**
	 * menu reference for different menus
	 */
	private static Menu mnu;

	/********* Address Bar Properties **********/
	/**
	 * the top vbox which contains menus
	 */
	private static VBox topPanel = new VBox();
	/**
	 * hbox which conatin url bar , go button
	 */
	private static HBox hbxAddressBar;
	/**
	 * url text field
	 */
	private static TextField txtfldAddress;
	/**
	 * url go button
	 */
	private static Button btnGo;
	/**
	 * toggle address bar
	 */
	private static boolean toggleAddress = true;
	/**
	 * toggle history bar
	 */
	private static boolean toggleHistory = true;
	/**
	 * toggle display code bar
	 */
	private static boolean toggleDispCode = true;
	/**
	 * web view reference
	 */
	private static WebView webViewRef = null;
	/**
	 * parent window ref
	 */
	private static BorderPane root = null;
	/**
	 * List of history urls
	 */
	private static ListView<String> list = null;
	/**
	 * xml content of page
	 */
	private static String xmlContent;
	/**
	 * text area to display xml 
	 */
	private static TextArea area;
	/**
	 * forward backward button
	 */
	private static HBox navigationBox;
	/**
	 * context menu for bookmarks
	 */
	private static ContextMenu cm = new ContextMenu();
	
	/********* Bookmarks Properties **********/
	/**
	 * list of bookmark urls
	 */
	private static ArrayList<String> bookmarkURLs = new ArrayList<>();

	/**
	 * the history object from engine
	 */
	private static WebHistory history;
	
	/**************** MenuBar ****************/
	/**
	 * returns the menubar with menus initialized
	 * @param wv - The webview
	 * @return Menubar with menus
	 */
	private static MenuBar getMenuBar(WebView wv) {
		MenuBar menuBar = new MenuBar();
		
		menuBar.getMenus().addAll(getMnuFile(wv), getMnuSettings(), getMnuBookmarks(), getMnuHelp());
		return menuBar;
	}



	
	/***************** Menu ******************/
	/**
	 * returns the File Menu
	 * @param wv
	 * @return File Menu
	 */
	private static Menu getMnuFile(WebView wv) {
		mnu = new Menu("File");
		mnu.getItems().addAll(getMnuItmRefresh(wv), getMnuItmExit());
		return mnu;
	}

	/**
	 * returns the settings menu
	 * @return Settings Menu
	 */
	private static Menu getMnuSettings() {
		mnu = new Menu("Settings");
		mnu.getItems().addAll(getMnuItmAddressBar(), getMnuItmSaveStartupPage(), getMnuItmHis(), getMnuItmDispCode());
		return mnu;
	}

	/**
	 * returns the bookmarks menu
	 * @return Bookmark Menu
	 */
	private static Menu getMnuBookmarks() {
		mnu = new Menu("Bookmarks");
		mnu.getItems().addAll(getMnuItmBookmarks(mnu));
		loadBookmarksToMenu(mnu);
		return mnu;
	}

	/**
	 * returns the help menu
	 * @return Help Menu
	 */
	private static Menu getMnuHelp() {
		mnu = new Menu("Help");
		mnu.getItems().addAll(getMnuItmJavaHelp(), getMnuItmAbout());
		return mnu;
	}

	
	/*************** MenuItems ***************/
	/**
	 * refresh menu item for refresh
	 * @param wv
	 * @return refresh menu item
	 */
	private static MenuItem getMnuItmRefresh(WebView wv) {
		mnuItm = new MenuItem("Refresh");
		mnuItm.setAccelerator(new KeyCodeCombination(KeyCode.F5, KeyCombination.CONTROL_DOWN));
		mnuItm.setOnAction(refreshPage(wv));
		return mnuItm;
	}



	/**
	 * exit menu item
	 * @return exit menu item
	 */
	private static MenuItem getMnuItmExit() {
		mnuItm = new MenuItem("Exit");
		mnuItm.setAccelerator(new KeyCodeCombination(KeyCode.F4, KeyCombination.CONTROL_DOWN));
		mnuItm.setOnAction(exitApp());
		return mnuItm;
	}


	/**
	 * save start up page menu item
	 * @return save start up page menu item
	 */
	private static MenuItem getMnuItmSaveStartupPage() {
		mnuItm.setAccelerator(new KeyCodeCombination(KeyCode.S, KeyCombination.CONTROL_DOWN));
		mnuItm = new MenuItem("Save Current Page as Startup");
		mnuItm.setOnAction(saveStartUpPage());
		return mnuItm;
	}


	/**
	 * History menu item
	 * @return History menu item
	 */
	private static MenuItem getMnuItmHis() {
		mnuItm = new MenuItem("History");
		mnuItm.setAccelerator(new KeyCodeCombination(KeyCode.H, KeyCombination.CONTROL_DOWN));
		mnuItm.setOnAction(toggleHistory());
		return mnuItm;
		
	}


	
	/**
	 * display code menu item
	 * @return display code menu item
	 */
	private static MenuItem getMnuItmDispCode() {
		mnuItm = new MenuItem("Display Code");
		mnuItm.setAccelerator(new KeyCodeCombination(KeyCode.D, KeyCombination.CONTROL_DOWN));
		mnuItm.setOnAction(displayCodeArea());
		return mnuItm;
		
	}

	/**
	 * address bar menu item
	 * @return address bar menu item
	 */
	private static MenuItem getMnuItmAddressBar() {
		
		mnuItm = new MenuItem("Show/Hide Address Bar");
		mnuItm.setAccelerator(new KeyCodeCombination(KeyCode.T, KeyCombination.CONTROL_DOWN));
		mnuItm.setOnAction(toggleAddressBar());
		return mnuItm;
	}

	/**
	 * bookmarks menu item
	 * @param mnuBookmarks 
	 * @return bookmarks menu item
	 */
	private static MenuItem getMnuItmBookmarks(Menu mnuBookmarks) {
		mnuItm = new MenuItem("Add Bookmark");
		mnuItm.setAccelerator(new KeyCodeCombination(KeyCode.B, KeyCombination.CONTROL_DOWN));
		mnuItm.setOnAction(handleBookMarks(mnuBookmarks));
		return mnuItm;
	}

	/**
	 * java help menu item
	 * @return java help menu item
	 */
	private static MenuItem getMnuItmJavaHelp() {
		mnuItm = new MenuItem("Java Help");
		mnuItm.setAccelerator(new KeyCodeCombination(KeyCode.F1, KeyCombination.CONTROL_DOWN));
		mnuItm.setOnAction(showHelp());
		return mnuItm;
	}


	/**
	 * about menu item
	 * @return about menu item
	 */
	private static MenuItem getMnuItmAbout() {
		/* From Marco Jakob, code.makery, */
		/* http://code.makery.ch/blog/javafx-dialogs-official/ */
		mnuItm = new MenuItem("About");
		mnuItm.setAccelerator(new KeyCodeCombination(KeyCode.F10, KeyCombination.CONTROL_DOWN));
		mnuItm.setOnAction(showAbout());
		return mnuItm;
	}

	
	/**
	 * Loads top panel, initialize history object etc.
	 * @param wv - The web view 
	 * @param parent - The parent window
	 * @return The container with menu
	 */
	public static VBox loadTopPanel(WebView wv, BorderPane parent) {
		
		hbxAddressBar = createAddressBar(wv);  
		webViewRef = wv;
		addLocationChangeListener(wv);
		root = parent;
		MenuBar mb = getMenuBar(wv);
	    topPanel.getChildren().add(mb);
	    history = webViewRef.getEngine().getHistory();
	    return topPanel;
	}

	

	/*************** Address Bar Methods ***************/
	/**
	 * creates address bar
	 * @param wv
	 * @return HBox containing address bar and buttons
	 */
	private static HBox createAddressBar(WebView wv) {

		Label lblEnterURL = new Label("Enter URL:");
		lblEnterURL.setPadding(new Insets(4, 4, 4, 4));

		txtfldAddress = new TextField();
		txtfldAddress.setOnKeyPressed(e -> {
			 if (e.getCode() ==
					 KeyCode.ENTER){
				 		loadUrl(wv);
					 }
		});
		btnGo = new Button("Go");
		btnGo.setOnAction((ActionEvent e) -> loadUrl(wv));
		
		HBox hbx = new HBox();	
		hbx.getChildren().addAll(lblEnterURL, txtfldAddress, btnGo);
		hbx.setHgrow(txtfldAddress, Priority.ALWAYS);
		return hbx;
	}
	
	/**
	 * Loads urls into web engine
	 * @param wv
	 */
	private static void loadUrl(WebView wv) {
		try {
			if(getCurrentURL() != null) {
				wv.getEngine().load(getCurrentURL());
				
			}
		} catch(StringIndexOutOfBoundsException | IllegalArgumentException ex ) {
			System.out.println("Some exception while loading page");
		}
		
		
	}


	/**
	 * sets url to textfield
	 * @param URL
	 */
	private static void setURL(String URL) {txtfldAddress.setText(URL);}
	/**
	 * returns current url from text field
	 * @return url
	 */
	private static String getCurrentURL() {
		try {
			return new URL(txtfldAddress.getText()).toExternalForm();
		}
		catch(MalformedURLException ex) {
			System.out.println("Invalid url");
			return null;
		}
		
	}
	/**
	 * 
	 * @param URL - The url to which web view should go
	 */
	public static void goToURL(String URL) {
		setURL(URL);
		btnGo.fire();
	}

	
	/*************** Bookmarks Methods ***************/
	
	/**
	 * 
	 * @return - Returns the bookmarks
	 */
	public static ArrayList<String> getBookmarks(){return bookmarkURLs;}
	/**
	 * 
	 * @param al - sets the bookmarks
	 */
	public static void setBookmarks(ArrayList<String> al) { bookmarkURLs = al;}
	
	/**
	 * loads bookmarks from file to menu item
	 * @param mnu
	 */
	private static void loadBookmarksToMenu(Menu mnu) {
		if (FileUtils.fileExists("bookmarks.web")){
			setBookmarks(FileUtils.getURLsFromFile("bookmarks.web"));
			for (String url: bookmarkURLs)
				addBookmarkToMenu(mnu, url);
		}
	}
	
	/**
	 *  adds bookmark to menu, here the logic of right click context menu is also written. On right click, a context menu is open
	 *  and remove bookmark option is given
	 * @param mnu
	 * @param URL
	 */
	private static void addBookmarkToMenu(Menu mnu, String URL) {
		CustomMenuItem cm1 = new CustomMenuItem( new Label(URL));
		cm1.setText(URL);
		cm1.getContent().addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
	        @Override public void handle(MouseEvent e) {
	        	
	        	if(e.getButton() == MouseButton.PRIMARY) {
	        		 goToURL(URL);
	        	}
	            if (e.getButton() == MouseButton.SECONDARY)  {
	            	MenuItem removeBookmark = new MenuItem("Remove Bookmark");
	        		removeBookmark.setOnAction((ActionEvent ev) ->{
	        			 
	        			bookmarkURLs.remove(bookmarkURLs.indexOf(URL));
	        			FileUtils.storeURLsToFile(bookmarkURLs, "bookmarks.web");
	        			mnu.getItems().clear();
	        			mnu.getItems().addAll(getMnuItmBookmarks(mnu));
	        			loadBookmarksToMenu(mnu);
	        		});
	        		cm.getItems().clear();
	        		cm.getItems().add(removeBookmark);
	            	cm.show(root, e.getScreenX(), e.getScreenY());
	            }
	                
	        }
	});
		if (mnu.getItems().size() == 1)
			mnu.getItems().add(new SeparatorMenuItem());
		mnu.getItems().add(cm1); // Add new URL to Menu
	}
	
	/**
	 * Hides history panel
	 */
	private static void hideHistory() {
	
		root.getChildren().remove(list);
		root.getChildren().remove(navigationBox);
	}


	/**
	 * Shows history panel
	 */
	private static void showHistory() {
		list = new ListView<String>();
		ObservableList<String> items =FXCollections.observableArrayList();
		for( Entry entry: webViewRef.getEngine().getHistory().getEntries()) {
			items.add(entry.getUrl() + '('+entry.getTitle()+')');
		}
		list.setItems(items);
		root.setRight(list);
		showBottomBar();
	}


	/**
	 * Displays the bottom bar with forward and backward buttons
	 */
	private static void showBottomBar() {
		
		
		Button btnFwd = new Button("Forward");
		Button btnBwd = new Button("Backward");
		btnFwd.setDisable(true);
		if(history.getCurrentIndex() == 0) {
			btnBwd.setDisable(true);
		}else {
			btnBwd.setDisable(false);
		}
		btnFwd.setOnAction((ActionEvent e) -> {
			
			int currentPage = history.getCurrentIndex();
			if(currentPage < history.getEntries().size()-1 ) {
				Platform.runLater(new Runnable() { public void run() { history.go(+1); } });
			}
			if(currentPage >= 0) {
				btnBwd.setDisable(false);
			}
			if(currentPage == history.getEntries().size()-2 ) {
				btnFwd.setDisable(true);
			}
			
		});
		btnBwd.setOnAction((ActionEvent e) ->  {
			int currentPage = history.getCurrentIndex();
			if(currentPage > 0 ) {
				Platform.runLater(new Runnable() { public void run() { history.go(-1); } });
			}
			if(currentPage == 1) {
				btnBwd.setDisable(true);
			}
			if(currentPage < history.getEntries().size() ) {
				btnFwd.setDisable(false);
			}
		});
		
		navigationBox = new HBox();	
		navigationBox.getChildren().addAll(btnBwd, btnFwd);
		navigationBox.setHgrow(txtfldAddress, Priority.ALWAYS);
		root.setBottom(navigationBox);
	}

	/**
	 * A location change listener is added which is used to update the url text field and also to get the display code 
	 * @param wv
	 */

	private static void addLocationChangeListener(WebView wv) {
		WebEngine webEngine = wv.getEngine();
		
		webEngine.getLoadWorker().stateProperty().addListener(new ChangeListener<State>() {
		     @Override
		     public void changed(ObservableValue ov, State oldState, State newState) {

		           if (newState == Worker.State.SUCCEEDED) {
		                 txtfldAddress.setText(webEngine.getLocation());
		                 try {
		                     TransformerFactory transformerFactory = TransformerFactory
		                         .newInstance();
		                     Transformer transformer = transformerFactory.newTransformer();
		                     StringWriter stringWriter = new StringWriter();
		                     transformer.transform(new DOMSource(webEngine.getDocument()),
		                         new StreamResult(stringWriter));
		                     xmlContent = stringWriter.getBuffer().toString();
		                     
		                   } catch (Exception e) {
		                     e.printStackTrace();
		                   }
		           }

		     }
		});
		
		
		
	}

	/**
	 * Removes the code panel where code is shown
	 */
	private static void hideCodePanel() {
		if(area != null && root.getChildren().contains(area)) {
			root.getChildren().remove(area);
		}
	}

	/**
	 * Shows code panel with xml data
	 */
	private static void showCodePanel() {
		if(xmlContent != null) {
			area = new TextArea();
			area.setText(xmlContent);;
			root.setBottom(area);
			
		}
	}

	/**
	 * Event handlers
	 */
	
	/**
	 * refreshes the page loaded
	 * @param wv
	 * @return EventHandler object
	 */
	private static EventHandler<ActionEvent> refreshPage(WebView wv) {
		return (ActionEvent e) -> wv.getEngine().reload();
	}

	/**
	 * exits from app
	 * @return EventHandler object
	 */
	private static EventHandler<ActionEvent> exitApp() {
		return (ActionEvent e) -> Platform.exit();
	}

	/**
	 * saves as start up page
	 * @return EventHandler object
	 */
	private static EventHandler<ActionEvent> saveStartUpPage() {
		return (ActionEvent e) -> {
			String currentURL = getCurrentURL();
			if (currentURL.length() > 0) {                  // if the currentURL is not ""...
				ArrayList<String> al = new ArrayList<>();
				al.add(currentURL);							// ...load it into the ArrayList and save it to the file
				FileUtils.storeURLsToFile(al, "default.web");
			}			
		};
	}
	

	/**
	 * toggles history
	 * @return EventHandler object
	 */
	private static EventHandler<ActionEvent> toggleHistory() {
		return (ActionEvent e) -> {
			if (toggleHistory)
				showHistory();
			else
				hideHistory();
			toggleHistory = !toggleHistory;
		};
	}
	
	/**
	 * toggles code display area
	 * @return EventHandler object
	 */
	private static EventHandler<ActionEvent> displayCodeArea() {
		return (ActionEvent e) -> {
			if (toggleDispCode)
				showCodePanel();
			else
				hideCodePanel();
			toggleDispCode = !toggleDispCode;
		};
	}
	
	/**
	 * toggles address bar
	 * @return EventHandler object
	 */
	private static EventHandler<ActionEvent> toggleAddressBar() {
		return (ActionEvent e) -> {
			if (toggleAddress)
				topPanel.getChildren().add(hbxAddressBar);
			else
				topPanel.getChildren().remove(hbxAddressBar);
			toggleAddress = !toggleAddress;
		};
	}
	
	/**
	 * handles bookmarks
	 * @param mnuBookmarks
	 * @return EventHandler object
	 */
	private static EventHandler<ActionEvent> handleBookMarks(Menu mnuBookmarks) {
		return (ActionEvent e) -> {
			addBookmarkToMenu(mnuBookmarks, getCurrentURL());
			getBookmarks().add(getCurrentURL());
		};
	}
	
	/**
	 * goto help
	 * @return EventHandler object
	 */
	private static EventHandler<ActionEvent> showHelp() {
		return (ActionEvent e) -> goToURL("https://www.google.ca/search?q=java");
	}
	
	/**
	 * display about dialogue
	 * @return EventHandler object
	 */
	private static EventHandler<ActionEvent> showAbout() {
		return (ActionEvent e) -> {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("About");
			alert.setHeaderText("Dave's Browser");
			alert.setContentText("Code by Prof. Dave Houtman, �2017");
			alert.showAndWait();
		};
	}
}
