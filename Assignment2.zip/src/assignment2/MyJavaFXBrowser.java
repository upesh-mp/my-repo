/**
 * FileName: MyJavaFXBrowser.java
 * Author: Manveer, ID
 * Course: 
 * Assignment: 2
 * Date: 11/1/2018
 * Professor: 
 * Purpose: 
 */
package assignment2;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

/**
 * 
 * @author Manveer
 * @version 1.0
 * @see javafx
 * @since 1.8
 *
 */
public class MyJavaFXBrowser extends Application {

	/**
	 * Here the actual application window opens up
	 * @param primaryStage
	 */
	@Override
	public void start(Stage primaryStage) {
		try {
			WebPage currentPage = new WebPage();
			WebView webView = currentPage.getWebView();
			
			BorderPane root = new BorderPane();
			root.setTop(Menus.loadTopPanel(webView, root));
			
			String startupURL = (FileUtils.fileExists("default.web"))?FileUtils.getURLsFromFile("default.web").get(0):"https://www.google.ca/";
			Menus.goToURL(startupURL);
			root.setCenter(webView);

			Scene scene = new Scene(root, 800, 500);
			primaryStage.setScene(scene);
			primaryStage.show();	
		}catch(Exception ex) {
			
		}
	    
	}
	
	@Override
	/**
	 * Stop the application, when application window is stopped, the URLs are stored to file
	 */
	public void stop() {
		FileUtils.storeURLsToFile(Menus.getBookmarks(), "bookmarks.web");
	}
	
	/**
	 * The Main entry point of application
	 * @param args
	 */
	public static void main(String[] args) {
		Application.launch(args);
	}

}
