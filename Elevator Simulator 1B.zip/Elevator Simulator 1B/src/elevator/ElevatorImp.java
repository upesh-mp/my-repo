package elevator;

import java.util.Observable;

import elevatorsystem.ElevatorPanel;

/**
 * ElevatorImp
 * Implementation of Elevator
 * It implemnts Observable and sends notification to all observers when moveTo is called.
 * @author Manveer
 *
 */
public class ElevatorImp extends Observable implements Elevator {

	final int POWER_START_STOP = 2;
	final int POWER_START_CONTINUOUS = 1;
	int capacity;
	int currentCapacity;
	ElevatorPanel elevatorPanel;
	MovingState currentState;
	int powerUsed;
	int currentFloor;

	/**
	 * Constructor which accepts the capacity of elevator and elevatory system
	 * object
	 * 
	 * @param i
	 * @param system
	 */
	public ElevatorImp(int i, ElevatorPanel system) {
		this.capacity = i;
		this.currentCapacity = 0;
		this.elevatorPanel = system;
		this.currentState = MovingState.Idle;
	}

	/**
	 * Returns the remaining capacity
	 */
	@Override
	public int getCapacity() {
		return capacity - currentCapacity;
	}

	/**
	 * Returns true if elevator is full else false
	 */
	@Override
	public boolean isFull() {
		return this.capacity == this.currentCapacity;
	}

	/**
	 * Returns true if elevator is empty else false
	 */
	@Override
	public boolean isEmpty() {
		return this.currentCapacity == 0;
	}

	/**
	 * Return current state of elevator
	 */
	@Override
	public MovingState getState() {
		return this.currentState;
	}

	/**
	 * Returns totla power consumed by elevator
	 */
	@Override
	public double getPowerConsumed() {
		return this.powerUsed;
	}

	/**
	 * Changes the state of elevator and updates the power consumed;
	 */
	@Override
	public void moveTo(int floor) {

		this.powerUsed += this.calculatePowerCosumption(floor);

		processMovingState(floor);

		this.setChanged();
		this.notifyObservers(floor);
		this.currentFloor = floor;
	}

	/**
	 * Returns current floor
	 */
	@Override
	public int getFloor() {
		return this.currentFloor;
	}

	/**
	 * Adds persons to elevator
	 */
	@Override
	public void addPersons(int persons) {
		if (persons > 0) {
			this.currentCapacity += persons;
		}

	}

	/**
	 * Calls elevator system to stop
	 */
	@Override
	public void requestStop(int floor) {

		this.currentState = MovingState.SlowDown;
		this.elevatorPanel.requestStop(floor, this);
		this.currentState = MovingState.Idle;

	}

	private int calculatePowerCosumption(int floor) {
		int difference = Math.abs(this.currentFloor - floor);
		if (difference == 1) {
			return 2;
		} else if (difference == 0) {
			return 0;
		} else {

			return (difference * POWER_START_CONTINUOUS) + POWER_START_STOP;
		}
	}

	private void processMovingState(int floor) {
		this.currentState = MovingState.SlowUp;
		if (this.currentFloor < floor) {
			this.currentState = MovingState.Up;
		} else {
			this.currentState = MovingState.Down;
		}
	}
}
