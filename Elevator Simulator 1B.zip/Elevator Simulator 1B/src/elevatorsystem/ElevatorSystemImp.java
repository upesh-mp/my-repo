package elevatorsystem;

import java.util.ArrayList;
import java.util.List;

import elevator.Elevator;

/**
 * ElevatorSystemImp
 * Implemnts ElevatorSystem, ElevatorPanel
 * @author Manveer
 *
 */
public class ElevatorSystemImp implements ElevatorSystem, ElevatorPanel {

	/**
	 * Minimum value of floor
	 */
	int minFloor;
	/**
	 * Maximum value of floor
	 */
	int maxFloor;
	/**
	 * List of elevators
	 */
	List<Elevator> elevators;

	/**
	 * Constructor which accepts min and max floors
	 * 
	 * @param mIN_FLOOR
	 * @param mAX_FLOOR
	 */
	public ElevatorSystemImp(int mIN_FLOOR, int mAX_FLOOR) {
		this.minFloor = mIN_FLOOR;
		this.maxFloor = mAX_FLOOR;
		this.elevators = new ArrayList<>();

	}

	/**
	 * Retuns total floors
	 */
	@Override
	public int getFloorCount() {
		return this.maxFloor - this.minFloor;
	}

	/**
	 * Returns maximum floor number
	 */
	@Override
	public int getMaxFloor() {

		return this.maxFloor;
	}

	/**
	 * Returns minimum floor number
	 */
	@Override
	public int getMinFloor() {
		return this.minFloor;
	}

	/**
	 * Moves elevator to the called floor
	 */
	@Override
	public Elevator callUp(int floor) {
		if (!this.floorCheck(floor)) {
			return null;
		}
		Elevator elevator = call(floor, false);
		elevator.moveTo(floor);
		return elevator;
	}

	/**
	 * Moves elevator to called floor
	 */
	@Override
	public Elevator callDown(int floor) {
		if (!this.floorCheck(floor)) {
			return null;
		}
		Elevator elevator = call(floor, false);
		elevator.moveTo(floor);
		return elevator;
	}

	/**
	 * Returns current floor of lift - since only one is present, returns its floor
	 * number
	 */
	@Override
	public int getCurrentFloor() {
		return this.elevators.get(0).getFloor();
	}

	/**
	 * Sums up power consumption of all lifts and returns
	 */
	@Override
	public double getPowerConsumed() {
		return this.calculatePowerCosumption();
	}

	/**
	 * Adds new elevator to list of elevators
	 */
	@Override
	public void addElevator(Elevator elevator) {
		this.elevators.add(elevator);
	}

	/**
	 * Moves elevator to that floor and stops
	 */
	@Override
	public void requestStop(int floor, Elevator elevator) {
		// When multiple elevators are present, we need to figure out which elevator
		// in the list
		if (this.floorCheck(floor)) {
			elevator.moveTo(floor);
		}

	}

	/**
	 * Here, if multiple elevators are present, we will return nearest elevator,
	 * since this assignment has only one elevator, return that elevator
	 */
	private Elevator call(int floor, boolean upOrDown) {
		return this.elevators.get(0);
	}

	/**
	 * Sum up all power consumptions
	 * 
	 * @return
	 */
	private int calculatePowerCosumption() {
		int total = 0;
		for (Elevator elevator : this.elevators) {
			total += elevator.getPowerConsumed();
		}
		return total;
	}

	/**
	 * Check if floor number is valid
	 * 
	 * @param floor
	 * @return
	 */
	boolean floorCheck(int floor) {
		if (floor > maxFloor || floor < minFloor) {
			return false;
		}
		return true;
	}

}
