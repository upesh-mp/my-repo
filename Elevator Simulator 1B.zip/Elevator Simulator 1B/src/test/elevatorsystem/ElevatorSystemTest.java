package test.elevatorsystem;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import elevator.Elevator;
import elevator.ElevatorImp;
import elevator.MovingState;
import elevatorsystem.ElevatorPanel;
import elevatorsystem.ElevatorSystem;
import elevatorsystem.ElevatorSystemImp;

class ElevatorSystemTest {

	@Test
	void testMinFloor() {
		ElevatorSystem system = new ElevatorSystemImp(1, 10);
		assertEquals(system.getMinFloor(), 1);
	}

	@Test
	void testMaxFloor() {
		ElevatorSystem system = new ElevatorSystemImp(1, 10);
		assertEquals(system.getMaxFloor(), 10);
	}
	
	@Test
	void testFloorCount() {
		ElevatorSystem system = new ElevatorSystemImp(1, 10);
		assertEquals(system.getFloorCount(), 9);
	}
	
	@Test
	void testCallUp() {
		ElevatorSystem system = new ElevatorSystemImp(1, 10);
		assertEquals(system.callUp(-1), null);
		Elevator  elevator = new ElevatorImp(0, null);
		system.addElevator(elevator);
		assertEquals(system.callUp(1), elevator);
	}
	
	
	@Test
	void testCallDown() {
		ElevatorSystem system = new ElevatorSystemImp(1, 10);
		assertEquals(system.callDown(-1), null);
		Elevator  elevator = new ElevatorImp(0, null);
		system.addElevator(elevator);
		assertEquals(system.callDown(1), elevator);
	}
	
	@Test
	void testGetCurrentFloor() {
		ElevatorSystem system = new ElevatorSystemImp(1, 10);
		Elevator  elevator = new ElevatorImp(0, null);
		system.addElevator(elevator);
		assertEquals(system.getCurrentFloor(), 0);
		system.callUp(6);
		assertEquals(system.getCurrentFloor(), 6);
	}
	
	@Test
	void testAddElevator() {
		ElevatorSystem system = new ElevatorSystemImp(1, 10);
		Elevator  elevator = new ElevatorImp(0, null);
		system.addElevator(elevator);
		assertEquals(system.callUp(1), elevator);
	}
	
	@Test
	void testGetPowerConsumed() {
		ElevatorSystem system = new ElevatorSystemImp(1, 10);
		Elevator  elevator = new ElevatorImp(0, null);
		system.addElevator(elevator);
		system.callUp(1);
		assertEquals(system.getPowerConsumed(), 2);
	}
	
	@Test
	void testRequestStop() {
		ElevatorSystemImp system = new ElevatorSystemImp(1, 10);
		Elevator  elevator = new ElevatorImp(0, null);
		system.addElevator(elevator);
		system.requestStop(5, elevator);
		assertEquals(elevator.getFloor(), 5);
	}
}
