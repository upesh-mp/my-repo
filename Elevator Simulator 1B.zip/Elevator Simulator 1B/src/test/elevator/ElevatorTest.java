/**
 * 
 */
package test.elevator;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Before;
import org.junit.jupiter.api.Test;

import elevator.ElevatorImp;
import elevator.MovingState;
import elevatorsystem.ElevatorPanel;
import elevatorsystem.ElevatorSystem;
import elevatorsystem.ElevatorSystemImp;

/**
 * @author Manveer
 *
 */
class ElevatorTest {

	ElevatorPanel system = new ElevatorSystemImp(0, 20);
	@Before
	void createElevatorSystem() {
		
	}
	@Test
	void checkInitialCapacity() {
		ElevatorImp imp = new ElevatorImp(10, system);
		assertEquals(imp.getCapacity(), 10);
	}
	
	@Test
	void checkCapacity() {
		ElevatorImp imp = new ElevatorImp(10, system);
		imp.addPersons(2);
		assertEquals(imp.getCapacity(), 8);
	}
	

	@Test
	void checkInitialState() {
		ElevatorImp imp = new ElevatorImp(10, system);
		assertEquals(imp.getState(), MovingState.Idle);
	}

	@Test
	void checkMovingUpState() {
		ElevatorImp imp = new ElevatorImp(10, system);
		imp.moveTo(10);
		assertEquals(imp.getState(), MovingState.Up);
	}
	
	@Test
	void checkMovingDownState() {
		ElevatorImp imp = new ElevatorImp(10, system);
		imp.moveTo(10);
		imp.moveTo(2);
		assertEquals(imp.getState(), MovingState.Down);
	}
	
	@Test
	void checkIsFullFalse() {
		ElevatorImp imp = new ElevatorImp(10, system);
		assertEquals(imp.isFull(), false);
	}
	
	@Test
	void checkIsFullTrue() {
		ElevatorImp imp = new ElevatorImp(10, system);
		imp.addPersons(10);
		assertEquals(imp.isFull(), true);
	}
	
	@Test
	void checkIsEmptyTrue() {
		ElevatorImp imp = new ElevatorImp(10, system);
		assertEquals(imp.isEmpty(), true);
	}
	
	@Test
	void checkIsEmptyFalse() {
		ElevatorImp imp = new ElevatorImp(10, system);
		imp.addPersons(1);
		assertEquals(imp.isEmpty(), false);
	}
	
	@Test
	void checkPowerConsumed() {
		ElevatorImp imp = new ElevatorImp(10, system);
		imp.addPersons(1);
		imp.moveTo(10);
		assertEquals(imp.getPowerConsumed(), 12);
	}
	
	@Test
	void checkMoveTo() {
		ElevatorImp imp = new ElevatorImp(10, system);
		imp.addPersons(1);
		imp.moveTo(10);
		assertEquals(imp.getPowerConsumed(), 12);
		assertEquals(imp.getState(), MovingState.Up);
		assertEquals(imp.getFloor(), 10);
	}
	
	@Test
	void checkGetFloor() {
		ElevatorImp imp = new ElevatorImp(10, system);
		imp.addPersons(1);
		imp.moveTo(8);
		assertEquals(imp.getFloor(), 8);
	}
	
	@Test
	void checkGetAddPersons() {
		ElevatorImp imp = new ElevatorImp(10, system);
		imp.addPersons(1);
		
		assertEquals(imp.getCapacity(), 9);
	}
	
	@Test
	void checkRequestStop() {
		ElevatorImp imp = new ElevatorImp(10, system);
		imp.addPersons(1);
		imp.requestStop(4);
		assertEquals(imp.getState(), MovingState.Idle);
		assertEquals(imp.getPowerConsumed(), 6);
	}
}
