package gui;


import java.awt.TextField;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import java.util.Queue;

import elevator.Elevator;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public  class ElevatorApplication extends Application implements Observer {

	private  int FLOOR_COUNT;

	private Label floors[];

	private Canvas canvas;
	
	private Simulator simulator;
	
	private ElevatorAnimation elevatorAnimation;
	
	BorderPane pane = new BorderPane();
	
	javafx.scene.control.TextField currentFloorFld;
	
	javafx.scene.control.TextField targetFloorFld;
	
	javafx.scene.control.TextField powerConsumedFld;

	@Override

	public void init() throws Exception {

		super.init(); 

		this.simulator = new Simulator(this);
		this.FLOOR_COUNT = this.simulator.getElevatorSystem().getMaxFloor()+1;
		this.elevatorAnimation = new ElevatorAnimation();
		floors= new Label[FLOOR_COUNT];
		for(int i=0;i<FLOOR_COUNT;i++) {

			floors [i]= new Label();

			floors[i].setId("empty");
		}

		floors[0].setId("elevator");

	}	
	@Override

	public void start(Stage primaryStage) {
		this.simulator.start();

		

		GridPane gridfloor= new GridPane();
		gridfloor.setHgap( 10);
		gridfloor.setVgap( 3);
		
		
		for(int i=FLOOR_COUNT-1;i>=0;i--) {

			gridfloor.add(floors[i], 0, (FLOOR_COUNT-1)-i);

		}
		
		this.currentFloorFld = new javafx.scene.control.TextField();
		this.currentFloorFld.setDisable(true);
		this.targetFloorFld = new javafx.scene.control.TextField();
		this.targetFloorFld.setDisable(true);
		this.powerConsumedFld = new javafx.scene.control.TextField();
		this.powerConsumedFld.setDisable(true);
		VBox box = new VBox();
		box.setPadding(new Insets(10));
	    box.setSpacing(8);
		box.getChildren().add(new Label("Current Floor"));
		box.getChildren().add(this.currentFloorFld);
		box.getChildren().add(new Label("Target Floor"));
		box.getChildren().add(this.targetFloorFld);
		box.getChildren().add(new Label("Power Consumed"));
		box.getChildren().add(this.powerConsumedFld);
		pane.setCenter(gridfloor);
		pane.setRight(box);
		Scene scene = new Scene(pane);

		scene.getStylesheets().add(ElevatorApplication.class.getResource("elevator.css").toExternalForm());
		
		scene.addEventHandler(KeyEvent.KEY_PRESSED, (KeyEvent event) -> {

			if(KeyCode.ESCAPE==event.getCode()) {
				this.elevatorAnimation.stop();

				primaryStage.hide();

			}           

		});

		TextField userTextField = new TextField();
		primaryStage.setScene(scene);
		primaryStage.setTitle("Elevator Simulator");
		primaryStage.show();
		//elevatorAnime.start();
		this.elevatorAnimation.start();
	}
	
	class ElevatorAnimation extends AnimationTimer {

		private static final long SECOND=1000000000l;
		private static final long NORMAL_SPEED=SECOND/6;
		private static final long SLOW_SPEED=SECOND/2;
		private  long lastUpdate= 0 ;
		private  long checkTime = SLOW_SPEED;
		private int step;
		
		public Queue< List< Integer>> queue = new LinkedList<>();
		private int targetFloor;
		private int currentFlooor=0;
		private boolean newTurn = true;
		
		@Override
		public void handle(long now) {
			if(now-lastUpdate<checkTime){

				return;
			}

			lastUpdate=now;
			
			
			
			if(newTurn) {
				List<Integer> list=  queue.poll();
				if(list == null) {
					return;
				}
				this.currentFlooor = list.get(0);
				currentFloorFld.setText(this.currentFlooor+"");
				this.targetFloor = list.get(1);
				targetFloorFld.setText(this.targetFloor+"");
				powerConsumedFld.setText(list.get(2) + "");
				newTurn=false;
				step=targetFloor-currentFlooor<0?-1:1;
				floors[targetFloor].setId("target");
			}
			else if(targetFloor==currentFlooor) {

				newTurn=true;

				floors[targetFloor].setId("elevator");
			}
			else {
				floors[currentFlooor].setId("empty");

				currentFlooor+=step;

				floors[currentFlooor].setId("elevator");
			}
			
			
		}
		
	}
	

	public static void main(String[] args) {

		launch(args);
	}

	@Override

	public void stop() throws Exception {

		// TODO Auto-generated method stub

		super.stop();

	}
	@Override
	public void update(Observable o, Object arg) {
 
		  System.out.println(" called with Arguments");
		  Elevator elevator = (Elevator)o;
		  this.addToQueue(elevator.getFloor(), (Integer)arg,(int) elevator.getPowerConsumed());
	}

	public void addToQueue(int cFloor, int tFloor, int energy) {
		List<Integer> list = new ArrayList<>();
		list.add(cFloor);
		list.add(tFloor);
		list.add(energy);
		this.elevatorAnimation.queue.add(list);
	}
}