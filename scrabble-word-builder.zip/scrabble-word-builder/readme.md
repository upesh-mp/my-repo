# Scrabble Word Builder

Your mission, if you choose to accept it, is to create an application (of any kind: api, cli, web, desktop, etc.) that produces the highest scoring word possible given the specified input values. 
  
  
You may use any language, framework, toolset, etc. to accomplish this task. The application can be as barebones or as elaborate as you’d like. However, a readme (or some form of documentation) with dependency, build, execution, and/or usage instructions must be supplied along with the source code.
  
## INPUT
The application must accept the following inputs:
 - rack: a string containing the letters on a player’s rack
 - word: (optional) a word that currently exists on the board that a player may be considering building off of
  
## RULES
The application must obey the following rules:
 - Player must have a minimum of 1 letter on their rack
 - Player must have a maximum of 7 letters on their rack
 - Words must be at least 2 letters long
 - Words must be 15 letters or less
 - Words must be in the (supplied) dictionary
  
## 
For this exercise, the following things may be ignored:
 - Blank tiles
 - Bonuses (double/triple word/letter scores)
 - Board layout
 - Word positioning
 - Any other things I forgot to mention
  
## CONSTANTS
The application must consider the following known constants (supplied):
 - Pre-defined word list – supplied as a simple text file with a single word per line
 - The number of each letter in the game (ex: there are 9 A’s but only 1 Z)
 - The score value of each letter
  
  
The letter information (count and scores) is provided in two forms (csv & json) as reference. You are free to use either (or none) of them at runtime as long as the application adheres to the values defined within.
  
  
**Have fun!** :thumbsup:

## EXAMPLES  
For reference, the following examples contain some sample inputs and what their respective output should be.
  
---

## Example 1:
### input
rack: `AIDOORW`
word: `WIZ`
### expected output
`WIZARD`
### explaination
This is a 19 point word score. Not bad!

---

## Example 2:
### input
rack: `AIDOORW`
word: _(none)_
### expected output
`DRAW`
### explaination
This would result in an 8 point word score. In this case, there are many other words (ex: WARD, WOOD, etc.) that can be produced. Any of these values are acceptable, we just chose the first value alphabetically.

---

## Example 3:
### input
rack: `AIDOORZ`
word: `QUIZ`
### expected output
_(invalid input)_
### explaination
This should produce some sort of validation error since there is only one Z available. A player couldn’t possibly have a Z on the board and in their rack.

---

## Example 4:
### input
rack: `AIDOORWZ`
word: _(anything)_
### expected output
_(invalid input)_
### explaination
This should produce a validation error because there are too many letters on the player’s rack.