/**
 * FileName: FileUtils.java
 * Author: Manveer, ID
 * Course: 
 * Assignment: 2
 * Date: 11/1/2018
 * Professor: 
 * Purpose: 
 */

package assignment2;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
/**
 * @author Manveer
 * @version 1.0
 * @see javafx.*
 * @since 1.8
 */
public class FileUtils {

	/**
	 * 
	 * @param f - the file handle
	 * @return if file exist or not
	 */
	public static boolean fileExists(File f) {
		return (f != null && f.exists() && f.isFile() && f.canRead() && (f.length()>2));
	}

	/**
	 * 
	 * @param s - file name
	 * @return if file exist or not
	 */
	public static boolean fileExists(String s) {
		return (fileExists(new File(s)));
	}

	/**
	 * 
	 * @param fileName - name of file from which urls are to be retrieved
	 * @return list of urls
	 */
	public static ArrayList<String> getURLsFromFile(String fileName) {
		ArrayList<String> al = new ArrayList<>();
		try {
			File f = new File(fileName);
			Scanner URLString = new Scanner(f);
			while (URLString.hasNext())
				al.add(URLString.next());
			URLString.close();
		} catch (FileNotFoundException e) {
		}
		return al;
	}

	/**
	 * 
	 * @param al - list of URLs to store
	 * @param fileName - Name of file to which URLs are to be stored
	 * @return The File
	 */
	public static File storeURLsToFile(ArrayList<String> al, String fileName) {
		File f = new File(fileName);
		if (FileUtils.fileExists(f)) f.delete();  // remove old bookmarks file
		try {
			PrintWriter pw = new PrintWriter(f);
			for (String s : al)	pw.println(s);
			pw.flush(); pw.close();
		} catch (FileNotFoundException e) {	}
		return f;
	}

}
