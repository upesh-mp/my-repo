/**
 * FileName: Menus.java
 * Author: Manveer, ID
 * Course: 
 * Assignment: 2
 * Date: 11/1/2018
 * Professor: 
 * Purpose: 
 */

package assignment2;

import java.io.StringWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Worker;
import javafx.concurrent.Worker.State;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.CustomMenuItem;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebErrorEvent;
import javafx.scene.web.WebHistory;
import javafx.scene.web.WebHistory.Entry;
import javafx.scene.web.WebView;

/**
 * @author Manveer
 * @version 1.0
 * @see javafx.*
 * @since 1.8
 */
public class Menus {

	/**** Generic Menu/Menu Item Properties ****/
	private static MenuItem mnuItm;
	/**
	 * menu reference for different menus
	 */
	private static Menu mnu;

	/********* Address Bar Properties **********/
	/**
	 * the top vbox which contains menus
	 */
	private static VBox topPanel = new VBox();
	/**
	 * url bar
	 */
	private static HBox hbxAddressBar;
	/**
	 * url field
	 */
	private static TextField txtfldAddress;
	/**
	 * url go button
	 */
	private static Button btnGo;
	/**
	 * toggle address bar
	 */
	private static boolean toggleAddress = true;
	/**
	 * toggle history bar
	 */
	private static boolean toggleHistory = true;
	/**
	 * toggle display code bar
	 */
	private static boolean toggleDispCode = true;
	/**
	 * web view reference
	 */
	private static WebView webViewRef = null;
	/**
	 * parent window ref
	 */
	private static BorderPane root = null;
	/**
	 * List of history urls
	 */
	private static ListView<String> list = null;
	/**
	 * xml content of page
	 */
	private static String xmlContent;
	/**
	 * text area to display xml 
	 */
	private static TextArea area;
	/**
	 * forward backward button
	 */
	private static HBox navigationBox;
	/**
	 * context menu for bookmarks
	 */
	private static ContextMenu cm = new ContextMenu();
	
	/********* Bookmarks Properties **********/
	private static ArrayList<String> bookmarkURLs = new ArrayList<>();

	
	/**************** MenuBar ****************/
	private static MenuBar getMenuBar(WebView wv) {
		MenuBar menuBar = new MenuBar();
		initializeRemoveBookmarkMenu();
		menuBar.getMenus().addAll(getMnuFile(wv), getMnuSettings(), getMnuBookmarks(), getMnuHelp());
		return menuBar;
	}



	
	/***************** Menu ******************/
	private static Menu getMnuFile(WebView wv) {
		mnu = new Menu("File");
		mnu.getItems().addAll(getMnuItmRefresh(wv), getMnuItmExit());
		return mnu;
	}

	private static Menu getMnuSettings() {
		mnu = new Menu("Settings");
		mnu.getItems().addAll(getMnuItmAddressBar(), getMnuItmSaveStartupPage(), getMnuItmHis(), getMnuItmDispCode());
		return mnu;
	}

	private static Menu getMnuBookmarks() {
		mnu = new Menu("Bookmarks");
		mnu.getItems().addAll(getMnuItmBookmarks(mnu));
		loadBookmarksToMenu(mnu);
		return mnu;
	}

	private static Menu getMnuHelp() {
		mnu = new Menu("Help");
		mnu.getItems().addAll(getMnuItmJavaHelp(), getMnuItmAbout());
		return mnu;
	}

	
	/*************** MenuItems ***************/
	private static MenuItem getMnuItmRefresh(WebView wv) {
		mnuItm = new MenuItem("Refresh");
		mnuItm.setAccelerator(new KeyCodeCombination(KeyCode.F5, KeyCombination.CONTROL_DOWN));
		mnuItm.setOnAction((ActionEvent e) -> wv.getEngine().reload());
		return mnuItm;
	}

	private static MenuItem getMnuItmExit() {
		mnuItm = new MenuItem("Exit");
		mnuItm.setAccelerator(new KeyCodeCombination(KeyCode.F4, KeyCombination.CONTROL_DOWN));
		mnuItm.setOnAction((ActionEvent e) -> Platform.exit());
		return mnuItm;
	}

	private static MenuItem getMnuItmSaveStartupPage() {
		mnuItm.setAccelerator(new KeyCodeCombination(KeyCode.S, KeyCombination.CONTROL_DOWN));
		mnuItm = new MenuItem("Save Current Page as Startup");
		mnuItm.setOnAction((ActionEvent e) -> {
			String currentURL = getCurrentURL();
			if (currentURL.length() > 0) {                  // if the currentURL is not ""...
				ArrayList<String> al = new ArrayList<>();
				al.add(currentURL);							// ...load it into the ArrayList and save it to the file
				FileUtils.storeURLsToFile(al, "default.web");
			}			
		});
		return mnuItm;
	}

	
	private static MenuItem getMnuItmHis() {
		mnuItm = new MenuItem("History");
		mnuItm.setAccelerator(new KeyCodeCombination(KeyCode.H, KeyCombination.CONTROL_DOWN));
		mnuItm.setOnAction((ActionEvent e) -> {
			if (toggleHistory)
				showHistory();
			else
				hideHistory();
			toggleHistory = !toggleHistory;
		});
		return mnuItm;
		
	}
	
	
	private static MenuItem getMnuItmDispCode() {
		mnuItm = new MenuItem("Display Code");
		mnuItm.setAccelerator(new KeyCodeCombination(KeyCode.D, KeyCombination.CONTROL_DOWN));
		mnuItm.setOnAction((ActionEvent e) -> {
			if (toggleDispCode)
				showCodePanel();
			else
				hideCodePanel();
			toggleDispCode = !toggleDispCode;
		});
		return mnuItm;
		
	}



	private static MenuItem getMnuItmAddressBar() {
		
		mnuItm = new MenuItem("Show/Hide Address Bar");
		mnuItm.setAccelerator(new KeyCodeCombination(KeyCode.T, KeyCombination.CONTROL_DOWN));
		mnuItm.setOnAction((ActionEvent e) -> {
			if (toggleAddress)
				topPanel.getChildren().add(hbxAddressBar);
			else
				topPanel.getChildren().remove(hbxAddressBar);
			toggleAddress = !toggleAddress;
		});
		return mnuItm;
	}

	private static MenuItem getMnuItmBookmarks(Menu mnuBookmarks) {
		mnuItm = new MenuItem("Add Bookmark");
		mnuItm.setAccelerator(new KeyCodeCombination(KeyCode.B, KeyCombination.CONTROL_DOWN));
		mnuItm.setOnAction((ActionEvent e) -> {
			addBookmarkToMenu(mnuBookmarks, getCurrentURL());
			getBookmarks().add(getCurrentURL());
		});
		return mnuItm;
	}

	private static MenuItem getMnuItmJavaHelp() {
		mnuItm = new MenuItem("Java Help");
		mnuItm.setAccelerator(new KeyCodeCombination(KeyCode.F1, KeyCombination.CONTROL_DOWN));
		mnuItm.setOnAction((ActionEvent e) -> goToURL("https://www.google.ca/search?q=java"));
		return mnuItm;
	}

	private static MenuItem getMnuItmAbout() {
		/* From Marco Jakob, code.makery, */
		/* http://code.makery.ch/blog/javafx-dialogs-official/ */
		mnuItm = new MenuItem("About");
		mnuItm.setAccelerator(new KeyCodeCombination(KeyCode.F10, KeyCombination.CONTROL_DOWN));
		mnuItm.setOnAction((ActionEvent e) -> {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("About");
			alert.setHeaderText("Dave's Browser");
			alert.setContentText("Code by Prof. Dave Houtman, �2017");
			alert.showAndWait();
		});
		return mnuItm;
	}
	
	/**
	 * 
	 * @param wv - The web view 
	 * @param parent - The parent window
	 * @return The container with menu
	 */
	public static VBox loadTopPanel(WebView wv, BorderPane parent) {
		hbxAddressBar = createAddressBar(wv);  
		webViewRef = wv;
		addLocationChangeListener(wv);
		root = parent;
		MenuBar mb = getMenuBar(wv);
	    topPanel.getChildren().add(mb);
	    return topPanel;
	}

	

	/*************** Address Bar Methods ***************/
	private static HBox createAddressBar(WebView wv) {

		Label lblEnterURL = new Label("Enter URL:");
		lblEnterURL.setPadding(new Insets(4, 4, 4, 4));

		txtfldAddress = new TextField();
		txtfldAddress.setOnKeyPressed(e -> {
			 if (e.getCode() ==
					 KeyCode.ENTER){
				 		loadUrl(wv);
					 }
		});
		btnGo = new Button("Go");
		btnGo.setOnAction((ActionEvent e) -> loadUrl(wv));
		
		HBox hbx = new HBox();	
		hbx.getChildren().addAll(lblEnterURL, txtfldAddress, btnGo);
		hbx.setHgrow(txtfldAddress, Priority.ALWAYS);
		return hbx;
	}
	
	private static void loadUrl(WebView wv) {
		try {
			if(getCurrentURL() != null) {
				wv.getEngine().load(getCurrentURL());
				System.out.println(wv.getEngine().getLoadWorker().getException());
			}
		} catch(StringIndexOutOfBoundsException | IllegalArgumentException ex ) {
			System.out.println("Some exception while loading page");
		}
		
		
	}


	private static void setURL(String URL) {txtfldAddress.setText(URL);}
	private static String getCurrentURL() {
		try {
			return new URL(txtfldAddress.getText()).toExternalForm();
		}
		catch(MalformedURLException ex) {
			System.out.println("Invalid url");
			return null;
		}
		
	}
	/**
	 * 
	 * @param URL - The url to which web view should go
	 */
	public static void goToURL(String URL) {
		setURL(URL);
		btnGo.fire();
	}

	
	/*************** Bookmarks Methods ***************/
	
	/**
	 * 
	 * @return - Returns the bookmarks
	 */
	public static ArrayList<String> getBookmarks(){return bookmarkURLs;}
	/**
	 * 
	 * @param al - sets the bookmarks
	 */
	public static void setBookmarks(ArrayList<String> al) { bookmarkURLs = al;}
	
	private static void loadBookmarksToMenu(Menu mnu) {
		if (FileUtils.fileExists("bookmarks.web")){
			setBookmarks(FileUtils.getURLsFromFile("bookmarks.web"));
			for (String url: bookmarkURLs)
				addBookmarkToMenu(mnu, url);
		}
	}
	
	private static void addBookmarkToMenu(Menu mnu, String URL) {
		CustomMenuItem cm1 = new CustomMenuItem( new Label(URL));
		cm1.setText(URL);
		cm1.getContent().addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
	        @Override public void handle(MouseEvent e) {
	        	
	        	if(e.getButton() == MouseButton.PRIMARY) {
	        		 goToURL(URL);
	        	}
	            if (e.getButton() == MouseButton.SECONDARY)  {
	            	MenuItem removeBookmark = new MenuItem("Remove Bookmark");
	        		removeBookmark.setOnAction((ActionEvent ev) ->{
	        			 
	        			bookmarkURLs.remove(bookmarkURLs.indexOf(URL));
	        			FileUtils.storeURLsToFile(bookmarkURLs, "bookmarks.web");
	        			mnu.getItems().clear();
	        			mnu.getItems().addAll(getMnuItmBookmarks(mnu));
	        			loadBookmarksToMenu(mnu);
	        		});
	        		cm.getItems().clear();
	        		cm.getItems().add(removeBookmark);
	            	cm.show(root, e.getScreenX(), e.getScreenY());
	            }
	                
	        }
	});
		if (mnu.getItems().size() == 1)
			mnu.getItems().add(new SeparatorMenuItem());
		mnu.getItems().add(cm1); // Add new URL to Menu
	}
	
	private static void hideHistory() {
	
		root.getChildren().remove(list);
		root.getChildren().remove(navigationBox);
	}


	private static void showHistory() {
		list = new ListView<String>();
		ObservableList<String> items =FXCollections.observableArrayList();
		for( Entry entry: webViewRef.getEngine().getHistory().getEntries()) {
			items.add(entry.getUrl() + '('+entry.getTitle()+')');
		}
		list.setItems(items);
		root.setRight(list);
		showBottomBar();
	}


	private static void showBottomBar() {
		
		
		Button btnFwd = new Button("Forward");
		Button btnBwd = new Button("Backward");
		btnFwd.setOnAction((ActionEvent e) -> {
			WebHistory history = webViewRef.getEngine().getHistory();
			int currentPage = history.getCurrentIndex();
			if(currentPage < history.getEntries().size()-1 ) {
				Platform.runLater(new Runnable() { public void run() { history.go(+1); } });
			}
			
		});
		btnBwd.setOnAction((ActionEvent e) ->  {
			WebHistory history = webViewRef.getEngine().getHistory();
			int currentPage = history.getCurrentIndex();
			if(currentPage > 0 ) {
				Platform.runLater(new Runnable() { public void run() { history.go(-1); } });
			}
		});
		
		navigationBox = new HBox();	
		navigationBox.getChildren().addAll(btnBwd, btnFwd);
		navigationBox.setHgrow(txtfldAddress, Priority.ALWAYS);
		root.setBottom(navigationBox);
	}


	private static void addLocationChangeListener(WebView wv) {
		WebEngine webEngine = wv.getEngine();
		
		webEngine.getLoadWorker().stateProperty().addListener(new ChangeListener<State>() {
		     @Override
		     public void changed(ObservableValue ov, State oldState, State newState) {

		           if (newState == Worker.State.SUCCEEDED) {
		                 txtfldAddress.setText(webEngine.getLocation());
		                 try {
		                     TransformerFactory transformerFactory = TransformerFactory
		                         .newInstance();
		                     Transformer transformer = transformerFactory.newTransformer();
		                     StringWriter stringWriter = new StringWriter();
		                     transformer.transform(new DOMSource(webEngine.getDocument()),
		                         new StreamResult(stringWriter));
		                     xmlContent = stringWriter.getBuffer().toString();
		                     
		                   } catch (Exception e) {
		                     e.printStackTrace();
		                   }
		           }

		     }
		});
		
	}


	private static void hideCodePanel() {
		if(area != null && root.getChildren().contains(area)) {
			root.getChildren().remove(area);
		}
	}


	private static void showCodePanel() {
		if(xmlContent != null) {
			area = new TextArea();
			area.setText(xmlContent);;
			root.setBottom(area);
			
		}
	}

	private static void initializeRemoveBookmarkMenu() {
		
	}

}
